"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { LoginSchema, LoginDTO } from '@/lib/auth';
import { login } from '@/lib/auth';
import { Role } from '@/types/models';

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginDTO>({ resolver: zodResolver(LoginSchema) });
  const onSubmit = async (data: LoginDTO) => {
    setError(null);
    try {
      const resp = await login(data);
      // Navigate based on role
      switch (resp.user.role) {
        case Role.LANDLORD:
          router.push('/(landlord)/dashboard');
          break;
        case Role.TENANT:
          router.push('/(tenant)/report-issue');
          break;
        case Role.CONTRACTOR:
          router.push('/(contractor)/jobs');
          break;
        case Role.OPS:
          router.push('/(ops)/queue');
          break;
        default:
          router.push('/');
      }
    } catch (err: any) {
      setError(err.detail || 'Login failed');
    }
  };
  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="mx-auto w-full max-w-md space-y-4 bg-white p-6 rounded shadow"
      >
        <h1 className="text-2xl font-semibold">Sign in</h1>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <div>
          <label htmlFor="email" className="block text-sm font-medium">
            Email
          </label>
          <input
            id="email"
            type="email"
            {...register('email')}
            className="mt-1 block w-full rounded border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
          {errors.email && <p className="text-xs text-red-600">{errors.email.message}</p>}
        </div>
        <div>
          <label htmlFor="password" className="block text-sm font-medium">
            Password
          </label>
          <input
            id="password"
            type="password"
            {...register('password')}
            className="mt-1 block w-full rounded border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
          />
          {errors.password && <p className="text-xs text-red-600">{errors.password.message}</p>}
        </div>
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full rounded bg-primary px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
        >
          {isSubmitting ? 'Signing in…' : 'Sign in'}
        </button>
        <p className="text-sm">
          Don't have an account?{' '}
          <a href="/signup" className="text-primary underline">
            Sign up
          </a>
        </p>
      </form>
    </div>
  );
}