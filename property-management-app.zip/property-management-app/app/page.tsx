"use client";

import { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { Role } from '@/types/models';

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();
  useEffect(() => {
    if (!loading) {
      if (!user) {
        router.replace('/login');
      } else {
        switch (user.role) {
          case Role.LANDLORD:
            router.replace('/(landlord)/dashboard');
            break;
          case Role.TENANT:
            router.replace('/(tenant)/report-issue');
            break;
          case Role.CONTRACTOR:
            router.replace('/(contractor)/jobs');
            break;
          case Role.OPS:
            router.replace('/(ops)/queue');
            break;
          default:
            router.replace('/login');
        }
      }
    }
  }, [user, loading, router]);
  return null;
}