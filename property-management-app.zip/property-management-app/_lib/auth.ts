import { z } from 'zod';
import { apiRequest, setAccessToken } from './apiClient';

/**
 * Zod schema and types for authentication flows. Both client and server can
 * import these schemas to ensure consistency between request payloads and
 * responses.
 */

export const LoginSchema = z.object({
  email: z.string().email({ message: 'Must be a valid email address' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

export type LoginDTO = z.infer<typeof LoginSchema>;

export const SignupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  fullName: z.string().min(2),
});

export type SignupDTO = z.infer<typeof SignupSchema>;

export const AcceptInviteSchema = z.object({
  token: z.string(),
  password: z.string().min(6),
});

export type AcceptInviteDTO = z.infer<typeof AcceptInviteSchema>;

export interface AuthResponse {
  accessToken: string;
  user: {
    id: string;
    email: string;
    fullName: string;
    role: string;
  };
}

/**
 * Log in with email and password. On success the access token is stored in
 * memory and the user profile is returned. The server will also set an
 * httpOnly refresh cookie.
 */
export async function login(dto: LoginDTO): Promise<AuthResponse> {
  const data = await apiRequest<AuthResponse>(`/auth/login`, {
    method: 'POST',
    body: JSON.stringify(dto),
    headers: { 'Content-Type': 'application/json' },
    skipAuth: true,
  });
  setAccessToken(data.accessToken);
  return data;
}

/**
 * Sign up as a landlord. After creation the user is logged in and can
 * continue onboarding by creating their first property.
 */
export async function signup(dto: SignupDTO): Promise<AuthResponse> {
  const data = await apiRequest<AuthResponse>(`/auth/signup`, {
    method: 'POST',
    body: JSON.stringify(dto),
    headers: { 'Content-Type': 'application/json' },
    skipAuth: true,
  });
  setAccessToken(data.accessToken);
  return data;
}

/**
 * Accept a tenant invite. The server will validate the invite token and set
 * the user’s role to TENANT. A password is required to complete the flow.
 */
export async function acceptInvite(dto: AcceptInviteDTO): Promise<AuthResponse> {
  const data = await apiRequest<AuthResponse>(`/invites/tenant/accept`, {
    method: 'POST',
    body: JSON.stringify(dto),
    headers: { 'Content-Type': 'application/json' },
    skipAuth: true,
  });
  setAccessToken(data.accessToken);
  return data;
}

/**
 * Fetch the currently authenticated user. Returns null if not logged in.
 */
export async function getMe() {
  try {
    const data = await apiRequest<AuthResponse['user']>(`/me`);
    return data;
  } catch (err) {
    return null;
  }
}

/**
 * Log out by clearing the access token and informing the server to revoke
 * refresh token. This is a best‑effort call; any error is swallowed.
 */
export async function logout(): Promise<void> {
  try {
    await apiRequest(`/auth/logout`, { method: 'POST' });
  } catch {
    /* ignore */
  } finally {
    setAccessToken(null);
  }
}